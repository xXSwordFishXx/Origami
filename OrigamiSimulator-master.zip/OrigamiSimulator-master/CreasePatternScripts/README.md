These are <a href="https://processing.org/" target="_blank">Processing</a> scripts I used to generate crease patterns 
for some of the examples in the app.  Processing exports pdfs with a 
clipping mask, you will need to pull this into a vector editing program to remove
the clipping mask and save as SVG before importing it into the Origami Simulator app.